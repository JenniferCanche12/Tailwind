/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors:{
        morado:'#CB7BD1',
        azul:'#7B9ED1',
        verde:' #9AD17B'
      }
    },
    fontfamily:{
      opensans:['Open Sans']
    }
  },
  plugins: [],
}